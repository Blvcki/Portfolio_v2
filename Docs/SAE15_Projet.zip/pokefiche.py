import requests
import sys
from md_to_html import convert

def download_poke(id: int) -> dict:
    """
    Prend un identifiant de Pokémon en argument et télécharge les données sur ce Pokémon via l’API.
    La documentation de cette API se situe à l’adresse https://pokeapi.co/docs/v2.

    Entréé : id, identifiant de Pokémon
    Sortie : donnee, dictionaire contenant les donnée du pokémon
    """
    # Effectuer une requête get pour récupérer les données du Pokémon
    reponse = requests.get("https://pokeapi.co/api/v2/pokemon/" + str(id))
    # Conversion en format json
    donnee = reponse.json()
    return donnee

def poke_to_md(data: dict, filename: str) -> None:
    """
    Prend un dictionnaire représentant un Pokémon et un nom de fichier, et génère un fichier Markdown représentant
    toutes les informations sur le Pokémon de façon structurée (titres, listes, etc). 
    """
    # Données importantes du Pokémon stuquées dans ces différentes variables
    # Nom 
    name = data["name"]
    # URL de l'image 
    image = data["sprites"]["front_default"]
    # Poids 
    poids = data["weight"]
    # Taille 
    taille = data["height"]
    # Liste des types
    if len(data["types"]) == 1:
        t1 = data["types"][0]["type"]["name"]
    else:
        t1 = data["types"][0]["type"]["name"]
        t2 = data["types"][1]["type"]["name"]
    # Points de vie 
    hp = data["stats"][0]["base_stat"]
    hpurl = requests.get(data["stats"][0]["stat"]["url"])
    hpdata = hpurl.json()
    # Dégâts  
    attack = data["stats"][1]["base_stat"]
    attackurl = requests.get(data["stats"][1]["stat"]["url"])
    attackdata = attackurl.json()
    # Défense 
    d = data["stats"][2]["base_stat"]
    durl = requests.get(data["stats"][2]["stat"]["url"])
    ddata = durl.json()
    # Attaque special
    sa = data["stats"][3]["base_stat"]
    saurl = requests.get(data["stats"][3]["stat"]["url"])
    sadata = saurl.json()
    # Défense special
    sd = data["stats"][4]["base_stat"]
    sdurl = requests.get(data["stats"][4]["stat"]["url"])
    sddata = sdurl.json()
    # Vitesse
    speed = data["stats"][5]["base_stat"]
    speedurl = requests.get(data["stats"][5]["stat"]["url"])
    speeddata = speedurl.json()


    #Création et écriture du fichier Markdown
    with open(filename, 'w') as file:
        # Nom du Pokémon, un titre de niveau 1
        file.write("# "  + name + "\n\n")
        
        # Image du Pokémon, titre de niveau 2
        file.write("## ![alt text](" + image + ") \n")
        
        # Écrire une liste non ordonnée Markdown
        file.write("- Poids: " + str(poids) + "\n")
        file.write("- Taille: " + str(taille) + "\n")
        if len(data["types"]) == 1:
            file.write("- Type: " + str(t1) + "\n")
        else:
            file.write("- Type: " + str(t1) + ", " + str(t2) + "\n")
        file.write("### Statistiques:\n")
        # Statistiques traduites en français
        file.write("- " + hpdata["names"][3]["name"] + ": " + str(hp) + "\n")
        file.write("- " + attackdata["names"][3]["name"] + ": " + str(attack) + "\n")
        file.write("- " + ddata["names"][3]["name"] + ": " + str(d) + "\n")
        file.write("- " + sadata["names"][3]["name"] + ": " + str(sa) + "\n")
        file.write("- " + sddata["names"][3]["name"] + ": " + str(sd) + "\n")
        file.write("- " + speeddata["names"][3]["name"] + ": " + str(speed) + "\n")

def fiche_pokemon(id: int) -> None:
    """
    Utilise les deux fonctions précédentes, ainsi que la fonction convert du fichier md_to_html, pour
    générer automatiquement une fiche Markdown et une fiche HTML à partir d’un identifiant PokeAPI.

    Entréé : id, identifiant Pokémon
    """
    # Télécharge les données du Pokémon
    data = download_poke(id)
    # Génére le fichier Markdown
    poke_to_md(data, data["name"]+".md")
    # Converti le fichier Markdown en Html
    convert(data["name"]+".md", data["name"]+".html")
    
if __name__ == "__main__":

    fiche_pokemon(sys.argv[1])

