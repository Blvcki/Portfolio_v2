# ------------------------------------------------------------------------------------------------------------------
# Objectif : Trier tous les Pokémons par type , puis comparer la moyenne des points de vie dans chaque catégorie. On
# saura ainsi si les Pokemons de type feu ont plus de points de vie ou pas.
# ------------------------------------------------------------------------------------------------------------------

import requests
import markdown
import sys
from md_to_html import convert


def  get_dataset(first_id: int, end_id: int)-> dict:
    """
    Télécharge, au format JSON, les données des pokemons compris entre le premier identifaint de pokemon (first_id)
    et le dernier (end_id).   

    Entrée : first_id et end_id, deux entier qui represente les identifants du premiers et du dernier pokemon, sois un intervale.
    Sortie : data, dictionnaire contenant les données des pokemon compris dans l'intervale.
    """
    # Dictionnaire contenant les données des Pokémons
    dataset = {}
    # Parcour sur les positions de tous les id des pokemons, end_id inclus.
    for i in range(first_id, end_id + 1 ):
        reponse = requests.get("https://pokeapi.co/api/v2/pokemon/" + str(i))
        dataset[i]= reponse.json()
    return dataset


def compute_avg_hp_by_type(dataset: dict) -> dict:
    """
    Calcule la moyenne des points de vie (HP) par type de Pokémon.
    
    Entrée : dataset, dictionnaire qui contiens les données des pokemon compris dans l'intervale, sortie de la fonction get_dataset.
    Sortie : avg_hp_by_type, dictionnaire qui contiens la moyenne des HP pour chaque type.
    
    """
    # Dictionnaire pour stocker la somme des HP et le nombre de Pokémon par type
    type_hp = {}

    for pokemon in dataset.values():
        # Intilaisation de la variable HP, qui va permettre de recupérer les points de vie (HP).
        hp = 0
        for stat in pokemon['stats']:
            if stat['stat']['name'] == 'hp':
                hp = stat['base_stat']
                # On s'arrête dès qu'on trouve la statistique
                break  
        
        # Récupérer les types du Pokémon
        for poke_type in pokemon['types']:
            type_name = poke_type['type']['name']
            # Initialiser le type si nécessaire
            if type_name not in type_hp:
                type_hp[type_name] = {"total_hp": 0, "count": 0}
            
            # Ajouter les HP 
            type_hp[type_name]['total_hp'] = type_hp[type_name]['total_hp'] + hp
            # Incrémenter le nombre de Pokémon
            type_hp[type_name]['count'] =  type_hp[type_name]['count'] + 1

    
    # Dictionnaire pour stocker la moyenne des HP pour chaque type
    avg_hp_by_type = {}
    # Calculer la moyenne avec une boucle for
    for poke_type, dataset in type_hp.items():
        # Vérifier qu'il y a au moins un Pokémon de ce type
        if dataset["count"] > 0:  
            avg_hp_by_type[poke_type] = dataset["total_hp"] / dataset["count"]

    return avg_hp_by_type


def dataset_to_md(dataset: dict, filename: str)-> None:
    """
    Permet de convertir la sortie de la focntion compute_avg_hp_by_type (un dictionnaire) en ficher markdown.

    Entrée : dataset, dictionnaire qui contiens la moyenne des HP pour chaque type, sortie de la fonction compute_avg_hp_by_type.
             filename, une chaîne de caractères qui represente le nom que l'on souhaite donner a notre fichier 

    Sortie : Renvoie rien.
    """
    # Calculer la moyenne des HP par type
    avg_hp_by_type = compute_avg_hp_by_type(dataset)
   
    # Calcule du type avec la meilleure moyenne
    # Initialisation de la moyenne max 
    max_moyenne = 0 
    # Initialisation du type max 
    max_type  = ""
    for poke_type, avg_hp in avg_hp_by_type.items():
        # Test si la moyenne et plus grande que la moyenne max
        if avg_hp > max_moyenne:
            # Si oui, la moyenne max devient la moyenne 
            max_moyenne = avg_hp
            # Le type max devient le type de cette moyenne
            max_type = poke_type  

    # Ouvrir le fichier en mode écriture
    with open(filename, 'w') as file:
        # Titres
        file.write("# Statistiques des Pokemons\n")
        file.write("## Cette analyse permet de comparer les points de vie moyens par type de Pokemon.\n\n")
        file.write("### Moyenne des HP des differents types de Pokemon\n")

        # Types de pokemon avec leur moyenne associées
        for poke_type, avg_hp in avg_hp_by_type.items():
            file.write(f"Type de Pokemon: {poke_type}, Moyenne des HP: {avg_hp:.2f} \n")
        
        # Conclusion, existe t'il un type qui a plus d'HP que les autres 
        file.write("\n## Type avec la plus haute moyenne de HP\n")
        file.write(f"Les Pokemon de type {max_type} ont en moyenne les HP les plus eleves : {max_moyenne:.2f}.\n")
            
        
        
def infos_locales(first_id: int, end_id: int)-> None:
    """
    Télécharge les données des Pokémons, génère un fichier Markdown et un fichier HTML contenant les statistiques.
    
    Entée  : first_id et end_id, deux entier qui represente les identifants du premiers et du dernier pokemon.
    Sortie : Renvoie rien
    """
    # Récupérer les données
    dataset = get_dataset(first_id, end_id)

    # Creation du fichier Markdown
    fichier_markdown = "pokemon_stats.md"
    dataset_to_md(dataset, fichier_markdown)

    # Convertion du fichier Markdown en HTML
    fichier_html = "pokemon_stats.html"

    # Ouverture du ficher markdown en lecture 
    with open(fichier_markdown, "r", encoding="utf-8") as md_file:
        text = md_file.read()
        html = markdown.markdown(text)
     # Ouverture du ficher html en écriture 
    with open(fichier_html, "w", encoding="utf-8", errors="xmlcharrefreplace") as html_file:
        html_file.write(html)

# Pokefiche avec toutes les langues

def download_poke(id: int) -> dict:
    """
    Prend un identifiant de Pokémon en argument et télécharge les données sur ce Pokémon via l'API.
    La documentation de cette API se situe à l'adresse https://pokeapi.co/docs/v2.

    Entréé : id, identifiant de Pokémon
    Sortie : donnee, dictionaire contenant les donnée du pokémon
    """
    # Effectuer une requête get pour récupérer les données du Pokémon
    reponse = requests.get("https://pokeapi.co/api/v2/pokemon/" + str(id))
    # Conversion en format json
    donnee = reponse.json()
    return donnee

def poke_to_md(data: dict, filename: str, l: int, n: int) -> None:
    """
    Prend un dictionnaire représentant un Pokémon et un nom de fichier, et génère un fichier Markdown représentant
    toutes les informations sur le Pokémon de façon structurée (titres, listes, etc). 
    """
    # Données importantes du Pokémon stuquées dans ces différentes variables

    # Nom 
    namedata = requests.get(data["species"]["url"]).json()
    # URL de l'image 
    image = data["sprites"]["front_default"]
    # Poids 
    poids = data["weight"]
    # Taille 
    taille = data["height"]
    # Liste des types
    if len(data["types"]) == 1:
        t1 = data["types"][0]["type"]["name"]
    else:
        t1 = data["types"][0]["type"]["name"]
        t2 = data["types"][1]["type"]["name"]
    # Points de vie 
    hp = data["stats"][0]["base_stat"]
    hpurl = requests.get(data["stats"][0]["stat"]["url"])
    hpdata = hpurl.json()
    # Dégâts  
    attack = data["stats"][1]["base_stat"]
    attackurl = requests.get(data["stats"][1]["stat"]["url"])
    attackdata = attackurl.json()
    # Défense 
    d = data["stats"][2]["base_stat"]
    durl = requests.get(data["stats"][2]["stat"]["url"])
    ddata = durl.json()
    # Attaque special
    sa = data["stats"][3]["base_stat"]
    saurl = requests.get(data["stats"][3]["stat"]["url"])
    sadata = saurl.json()
    # Défense special
    sd = data["stats"][4]["base_stat"]
    sdurl = requests.get(data["stats"][4]["stat"]["url"])
    sddata = sdurl.json()
    # Vitesse
    speed = data["stats"][5]["base_stat"]
    speedurl = requests.get(data["stats"][5]["stat"]["url"])
    speeddata = speedurl.json()


    #Création et écriture du fichier Markdown
    with open(filename, 'w') as file:
        # Nom du Pokémon, un titre de niveau 1
        file.write("# "  + namedata["names"][n]["name"] + "\n\n")
        
        # Image du Pokémon, titre de niveau 2
        file.write("## ![alt text](" + image + ") \n")
        
        # Écrire une liste non ordonnée Markdown
        file.write("- Poids: " + str(poids) + "\n")
        file.write("- Taille: " + str(taille) + "\n")
        if len(data["types"]) == 1:
            file.write("- Type: " + str(t1) + "\n")
        else:
            file.write("- Type: " + str(t1) + ", " + str(t2) + "\n")
        file.write("### Statistiques:\n")
        # Statistiques traduites en français
        file.write("- " + hpdata["names"][l]["name"] + ": " + str(hp) + "\n")
        file.write("- " + attackdata["names"][l]["name"] + ": " + str(attack) + "\n")
        file.write("- " + ddata["names"][l]["name"] + ": " + str(d) + "\n")
        file.write("- " + sadata["names"][l]["name"] + ": " + str(sa) + "\n")
        file.write("- " + sddata["names"][l]["name"] + ": " + str(sd) + "\n")
        file.write("- " + speeddata["names"][l]["name"] + ": " + str(speed) + "\n")

def fiche_pokemon(id: int, lang: str) -> None:
    """
    Utilise les deux fonctions précédentes, ainsi que la fonction convert du fichier md_to_html, pour
    générer automatiquement une fiche Markdown et une fiche HTML à partir d’un identifiant PokeAPI.

    Entréé : id, identifiant Pokémon
    """
    # Choix de langage
    if lang not in ["ja-Hrkt", "ko", "zh-Hant", "fr", "de", "es", "it", "en", "zh-Hans"]:
        err = "Language available: en, fr, ja-Hrkt, ko, de, es, it, zh-Hant, zh-Hans"
        print('Language available: en, fr, ja-Hrkt, ko, de, es, it, zh-Hant, zh-Hans')
        return err
    if lang == "ja-Hrkt":
        l = 0
        n = 0
    if lang == "ko":
        l = 1
        n = 2
    if lang == "zh-Hant":
        l = 2
        n = 3
    if lang == "fr":
        l = 3
        n = 4
    if lang == "de":
        l = 4
        n = 5
    if lang == "es":
        l = 5
        n = 6
    if lang == "it":
        l = 6
        n = 7
    if lang == "en":
        l = 7
        n = 8
    if lang == "zh-Hans":
        l = 8
        n = 10
    
    # Télécharge les données du Pokémon
    data = download_poke(id)
    # Génére le fichier Markdown
    poke_to_md(data, data["name"]+".md", l, n)
    # Converti le fichier Markdown en Html
    convert(data["name"]+".md", data["name"]+".html")
    

if __name__ == "__main__":
    # Si les arguments sont plus que 3 (en comptant le fichier), il renvoie une explication.
    if len(sys.argv) != 3:
        print("Comment utiliser ?: projet2.py <pokemon_id> <langage>")
        print("Exemple: projet.py 25 en")
    try:
        pokemon_id = sys.argv[1]
        langage = sys.argv[2]
        fiche_pokemon(pokemon_id, langage)
    # En cas d'erreur d'insertion sur l'ID, il renvoie un rappel. 
    except ValueError:
        print("Erreur: Pokémon ID doit être un entier.")
        
