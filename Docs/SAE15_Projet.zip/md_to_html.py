import markdown
import sys 

def convert(first: str, second: str) -> str:
    """
    Converti le premier fichier en le second

    Entréés : first, nom de fichier Markdown
              second, nom de fichier HTML 
    """

    # Ouvre le fichier Markdown en mode lecture avec l'encodage UTF-8
    with open(first, "r", encoding="utf-8", errors="replace") as file:
        # Lire tout le contenu du fichier Markdown
        text = file.read()
    # Convertir le texte Markdown en HTML
    html = markdown.markdown(text)
    # Ouvre le fichier HTML en mode écriture avec l'encodage UTF-8
    with open(second, "w", encoding="utf-8", errors="xmlcharrefreplace") as output_file:
        # Écrire le contenu HTML dans le fichier de sortie
        output_file.write(html)

if __name__ == "__main__":
# execute only if run as a script

    convert(sys.argv[1], sys.argv[2])